import os
import glob
import hmac
import base64
import hashlib
import javaobj.v2 as javaobj
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from Crypto.Cipher import AES
import pyshark
import subprocess
import sys
import argparse
import binascii
import struct
import time

def print_green(text): print(f"\033[92m{text}\033[0m")
def print_yellow(text): print(f"\033[93m{text}\033[0m")
def print_red(text): print(f"\033[91m{text}\033[0m")

def get_private_key(key_file):
    print(f"[*] Loading private key from {key_file}...")
    try:
        with open(key_file, "rb") as fd:
            pobj = javaobj.load(fd)
        key_data = bytes(map(lambda x: x & 0xFF, pobj.array.value.privateKey.encoded.data))
        formatted_key = f"-----BEGIN PRIVATE KEY-----\n"
        formatted_key += base64.encodebytes(key_data).decode()
        formatted_key += f"-----END PRIVATE KEY-----"
        return RSA.import_key(formatted_key.encode())
    except Exception as e:
        print_red(f"[!] Failed to load key file: {e}")
        return None

def decrypt_metadata(priv_key, b64_metadata):
    cipher = PKCS1_v1_5.new(priv_key)
    try:
        try:
            decoded = base64.b64decode(b64_metadata)
        except:
            return None
            
        decrypted = cipher.decrypt(decoded, 0)
        if decrypted[0:4] == b'\x00\x00\xbe\xef':
            return decrypted[8:24]
    except:
        pass
    return None

def extract_keys_from_pcap(pcap_file, priv_key):
    keys = set()
    print_yellow(f"[*] Scanning {pcap_file} for metadata to extract keys...")
    
    try:
        cap = pyshark.FileCapture(pcap_file, display_filter="http", use_json=True, include_raw=True)
        
        count = 0
        for pkt in cap:
            count += 1
            if count % 500 == 0:
                print(f"    Processed {count} packets...", flush=True)

            metadata_candidates = []
            
            if not hasattr(pkt, 'http'):
                continue
                
            if hasattr(pkt.http, 'cookie'):
                val = pkt.http.cookie
                metadata_candidates.append(val)
                if '=' in val:
                    metadata_candidates.append(val.split('=')[-1].strip())
            
            if hasattr(pkt.http, 'authorization'):
                auth = pkt.http.authorization
                parts = auth.split(' ')
                if len(parts) > 1:
                    metadata_candidates.append(parts[1].strip())
            
            for candidate in metadata_candidates:
                if len(candidate) < 20:
                    continue
                
                raw_key = decrypt_metadata(priv_key, candidate)
                if raw_key:
                    sha256_hash = hashlib.sha256(raw_key).digest()
                    aes_key = sha256_hash[:16]
                    hmac_key = sha256_hash[16:]
                    key_tuple = (hmac_key.hex(), aes_key.hex())
                    
                    if key_tuple not in keys:
                        print_green(f"[+] Found NEW Key in packet {pkt.number}")
                        print(f"    HMAC: {key_tuple[0]}")
                        print(f"    AES:  {key_tuple[1]}")
                        keys.add(key_tuple)
        
        cap.close()
    except Exception as e:
        print_red(f"[!] Error processing pcap {pcap_file}: {e}")
        
    return list(keys)

def run_analysis(pcap_file, keys, out_dir):
    script_path = "cs-parse-http-traffic.py"
    if not os.path.exists(script_path):
        print_red(f"[!] {script_path} not found!")
        return

    if not keys:
        print_yellow(f"[-] No keys to run analysis for {pcap_file}")
        return

    base_name = os.path.splitext(os.path.basename(pcap_file))[0]
    
    for idx, (hmac_k, aes_k) in enumerate(keys):
        key_arg = f"{hmac_k}:{aes_k}"
        output_file = os.path.join(out_dir, f"result_{base_name}_key{idx+1}.txt")
        
        print_yellow(f"[*] Running analysis on {pcap_file} with Key #{idx+1}...")
        print(f"    Output will be saved to: {output_file}")
        
        cmd = [sys.executable, script_path, "-k", key_arg, pcap_file]
        
        try:
            os.makedirs(out_dir, exist_ok=True)
            with open(output_file, "w", encoding="utf-8") as outfile:
                subprocess.run(cmd, stdout=outfile, stderr=subprocess.STDOUT, check=False)
            print_green(f"[+] Analysis complete! Check {output_file}")
        except Exception as e:
            print_red(f"[!] Failed to run analysis: {e}")

def normalize_existing_files(paths):
    normalized = []
    for path in paths:
        if path == "":
            continue
        p = os.path.abspath(path)
        if os.path.exists(p):
            normalized.append(p)
        else:
            print_red(f"[!] File not found: {path}")
    return normalized

def discover_pcaps():
    pcaps = glob.glob("*.pcap") + glob.glob("*.pcapng") + glob.glob("example/*.pcap*")
    return list(set([os.path.abspath(p) for p in pcaps if os.path.exists(p)]))

def discover_key_file():
    key_files = glob.glob("*.beacon_keys")
    if not key_files:
        return None
    return os.path.abspath(key_files[0])

def parse_args():
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument("-p", "--pcap", action="append", default=[], help="指定 pcap/pcapng 文件，可重复多次")
    parser.add_argument("-k", "--key-file", default="", help="指定 cobaltstrike.beacon_keys 文件路径")
    parser.add_argument("-o", "--out-dir", default="output", help="结果导出目录")
    parser.add_argument("--no-color", action="store_true", help="关闭彩色输出")
    return parser.parse_args()

def banner(no_color=False):
    art = r"""
      ______      ______                     _
     / ____/___  / ____/________ _____  ____(_)___  ________
    / /   / __ \/ /   / ___/ __ `/ __ \/ __/ / __ \/ ___/ _ \
   / /___/ /_/ / /___/ /  / /_/ / / / / /_/ / / / / /__/  __/
   \____/\____/\____/_/   \__,_/_/ /_/\__/_/_/ /_/\___/\___/

                   Nick: Ccan | CS Traffic Decryptor
             One-Shot: Key -> Decrypt -> Parse -> Export TXT
    """
    if no_color:
        print(art)
    else:
        print("\033[96m" + art + "\033[0m")

def main():
    args = parse_args()
    if args.no_color:
        globals()["print_green"] = lambda text: print(text)
        globals()["print_yellow"] = lambda text: print(text)
        globals()["print_red"] = lambda text: print(text)

    banner(no_color=args.no_color)
    print_green("=== Cobalt Strike Traffic Decryptor 'Yi Ba Suo' ===")
    
    key_file = args.key_file.strip()
    if key_file == "":
        key_file = discover_key_file()
    else:
        key_file = os.path.abspath(key_file)

    if not key_file or not os.path.exists(key_file):
        print_red("[!] No .beacon_keys file found (use -k to specify).")
        return

    print(f"[*] Using Key File: {key_file}")
    
    priv_key = get_private_key(key_file)
    if not priv_key:
        return

    pcap_files = normalize_existing_files(args.pcap)
    if not pcap_files:
        pcap_files = discover_pcaps()
    
    if not pcap_files:
        print_red("[!] No pcap files found (use -p to specify).")
        return

    print(f"[*] Found {len(pcap_files)} pcap files.")

    for pcap in pcap_files:
        print("\n" + "="*50)
        print(f"[*] Processing: {pcap}")
        found_keys = extract_keys_from_pcap(pcap, priv_key)
        
        if found_keys:
            print(f"[*] Found {len(found_keys)} unique keys.")
            run_analysis(pcap, found_keys, os.path.abspath(args.out_dir))
        else:
            print_red(f"[-] No keys found in {pcap}. Skipping analysis.")

    print("\n" + "="*50)
    print_green("[*] All tasks finished.")

if __name__ == "__main__":
    main()
